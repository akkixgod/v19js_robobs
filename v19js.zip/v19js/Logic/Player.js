class Player {
    token = "";
    name = "JSV19";
    constructor(){
        //
    }
}

module.exports = Player