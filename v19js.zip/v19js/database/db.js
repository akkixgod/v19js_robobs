// В файле db.js
const mysql = require('mysql2');

const pool = mysql.createPool({
  host: '91.223.3.177',
  user: 'u11628_LYOL1qdTG0',
  password: '^FpOA8D78QkS+^7AWLzlobCD',
  database: 's11628_robobrawl',
  port: 3306,
  connectionLimit: 10, // Количество соединений в пуле
});

function createTable() {
  return new Promise((resolve, reject) => {
    pool.getConnection((err, connection) => {
      if (err) {
        console.error('Error getting connection from pool:', err);
        reject('Error getting connection from pool');
        return;
      }

      // Создание таблицы, если её еще нет
      const createTableQuery = `
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          token TEXT NOT NULL,
          data JSON NOT NULL
        )
      `;

      connection.query(createTableQuery, (error, results, fields) => {
        connection.release();
        if (error) {
          console.error('Error creating table:', error);
          reject('Error creating table');
        } else {
          resolve('Table created or already exists');
        }
      });
    });
  });
}

function createAccount(token, additionalData) {
    return new Promise((resolve, reject) => {
      pool.getConnection((err, connection) => {
        if (err) {
          console.error('Error getting connection from pool:', err);
          reject('Error getting connection from pool');
          return;
        }
  
        const insertQuery = `
          INSERT INTO users (token, data)
          VALUES (?, ?)
        `;
  
        const values = [token, JSON.stringify(additionalData)];
  
        connection.query(insertQuery, values, (error, results, fields) => {
          connection.release();
          if (error) {
            console.error('Error creating account:', error);
            reject(`Ошибка создания аккаунта обратись к админу`);
          } else {
            // Resolve with the ID of the newly created account
            resolve(results.insertId);
          }
        });
      });
    });
  }

function loadAccount(token) {
    return new Promise((resolve, reject) => {
      pool.getConnection((err, connection) => {
        if (err) {
          console.error('Error getting connection from pool:', err);
          reject('Error getting connection from pool');
          return;
        }
  
        // Query to retrieve an account based on the token
        const selectQuery = `
          SELECT * FROM users
          WHERE token = ?
        `;
  
        connection.query(selectQuery, [token], (error, results, fields) => {
          connection.release();
          if (error) {
            console.error('Error loading account:', error);
            reject('Error loading account');
          } else {
            if (results.length > 0) {
              // Account found, resolve with the account data
              resolve(results[0]);
            } else {
              // No account found with the given token
              reject('Account not found');
            }
          }
        });
      });
    });
  }
  function replaceValue(token, key, newValue) {
    return new Promise((resolve, reject) => {
      pool.getConnection((err, connection) => {
        if (err) {
          console.error('Error getting connection from pool:', err);
          reject('Error getting connection from pool');
          return;
        }
  
        // Update the specified key with the new value
        const updateQuery = `
          UPDATE users
          SET data = JSON_SET(data, '$.${key}', ?)
          WHERE token = ?
        `;
  
        const values = [newValue, token];
  
        connection.query(updateQuery, values, (error, results, fields) => {
          connection.release();
          if (error) {
            console.error('Error updating value:', error);
            reject('Error updating value');
          } else {
            resolve('Value updated successfully');
          }
        });
      });
    });
  }
  

createTable();
module.exports = {
  createAccount,
  createTable,
  loadAccount,
  replaceValue
};
