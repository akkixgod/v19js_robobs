const PiranhaMessage = require('../../../PiranhaMessage') // You should change it if you transfer this file in another subdirectory
const ByteStream = require("../../../../ByteStream")
const SetNameCallback = require('../../Server/Home/SetNameCallback')
const db = require('../../../../database/db');

class ChangeAvatarNameMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 10212
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    this.session.Player.name = this.stream.readString()
  }

  async process () {
    db.replaceValue(this.session.Player.token, 'name', this.session.Player.name)
    .then((message) => {
      new SetNameCallback(this.session).send()
    })
    .catch((error) => {
      console.error('Error updating value:', error);
      // Handle the error, e.g., send an error response to the client
    });
  }
}

module.exports = ChangeAvatarNameMessage
