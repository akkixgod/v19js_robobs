const PiranhaMessage = require('../../../PiranhaMessage') // You should change it if you transfer this file in another subdirectory
const ByteStream = require("../../../../ByteStream")
const ServerHelloMessage = require('../../Server/Auth/ServerHelloMessage')
const LoginFailedMessage = require('../../Server/Login/LoginFailedMessage')
const LoginOKMessage = require('../../Server/Login/LoginOKMessage')
const OwnHomeDataMessage = require('../../Server/Home/OwnHomeDataMessage')
const config = require("../../../../config.json")
const db = require("../../../../database/db")
const { generateRandomString } = require('../../../../Utils/Helper');

class ClientLoginMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 10101
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    this.stream.readInt()//0 HighID
    this.session.Player.lowID = this.stream.readInt()//0 lowID
    this.session.Player.token = this.stream.readString()//token maybe

    this.major = this.stream.readInt()//19
    this.minor = this.stream.readInt()//0
    this.build = this.stream.readInt()//111

  }

  async process() {
    if (this.session.Player.token === '') {
      this.session.Player.token = generateRandomString(40);
      const data = this.session.Player;
  
      db.createAccount(this.session.Player.token, data)
        .then((accountId) => {
          if (accountId) {
            this.session.Player.lowID = accountId;
            db.loadAccount(this.session.Player.token)
              .then((account) => {  
                this.session.Player = account.data
                new LoginOKMessage(this.session).send();
                new OwnHomeDataMessage(this.session).send();
              })
              .catch((error) => {
                console.error('Error loading account after creation:', error);
                // Handle the error, e.g., show an error message to the user
              });
          } else {
            new LoginFailedMessage(this.session, 'Failed to create account', 8).send();
          }
        })
        .catch((error) => {
          console.error('Error creating account:', error);
        });
    } else {
      db.loadAccount(this.session.Player.token)
        .then((account) => {  
          this.session.Player = account.data
          console.log(account.data)
          new LoginOKMessage(this.session).send();
          new OwnHomeDataMessage(this.session).send();
        })
        .catch((error) => {
          if (error === 'Account not found') {
            new LoginFailedMessage(this.session, 'Удалите все данные о игре! Аккаунт не найден', 8).send();
          } else {
            console.error('Error loading account:', error);
            // Handle the error, e.g., show an error message to the user
          }
        });
    }
  }
  
}

module.exports = ClientLoginMessage
