
const PiranhaMessage = require('../../../PiranhaMessage')
const ByteStream = require("../../../../ByteStream")

class LoginFailedMessage extends PiranhaMessage {
  constructor (session, msg, errCode) {
    super(session)
    this.id = 20103
    this.session = session
    this.msg = msg
    this.errCode = errCode
    this.version = 0
    this.stream = new ByteStream()
  }

  async encode () {
    this.stream.writeInt(this.errCode)

    this.stream.writeString() // your finger
    this.stream.writeString() // serverHost

    this.stream.writeString() // patchurl
    this.stream.writeString() // updateurl
    this.stream.writeString(this.msg)

    this.stream.writeInt(3600)
    this.stream.writeBoolean(false)

    this.stream.writeString()
    this.stream.writeString()

    this.stream.writeLong(0, 3)

    this.stream.writeString()
    this.stream.writeString()

    this.stream.writeLong(0, 0)

    this.stream.writeBoolean(false)
    this.stream.writeBoolean(false)
  }
}

module.exports = LoginFailedMessage
