const PiranhaMessage = require('../../../PiranhaMessage')
const ByteStream = require("../../../../ByteStream")

class OwnHomeDataMessage extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 24101
    this.session = session
    this.version = 0
    this.stream = new ByteStream()
  }

  async encode () {
    this.stream.writeVInt(666)
    this.stream.writeVInt(666)

    this.stream.writeVInt(37500)
    this.stream.writeVInt(37500)

    this.stream.writeVInt(0)
    this.stream.writeVInt(95)

    this.stream.writeVInt(999999)

    this.stream.writeDataReference(28, 1)//this.player.thumbnail
    this.stream.writeDataReference(43, 0)//this.player.nameColor

    this.stream.writeVInt(0) // PlayedGamemodesArray
    this.brawlers = []
    this.skins = []
    this.stream.writeVInt(this.brawlers.length) // SelectedSkins
    for (const brawler of this.brawlers) {
      this.stream.writeDataReference(29, brawler.skin)
    }

    this.stream.writeVInt(this.skins.length) // UnlockedSkins

    for(let skin of this.skins){
      this.stream.writeDataReference(29, skin)
    }

    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)

    this.stream.writeBoolean(false)
    this.stream.writeVInt(1)
    this.stream.writeBoolean(true)

    this.stream.writeVInt(0) 
    this.stream.writeVInt(0)

    this.stream.writeByte(8)

    this.stream.writeBoolean(false)
    this.stream.writeBoolean(false)
    this.stream.writeBoolean(false)

    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.offers = []
    this.stream.writeVInt(this.offers.length) // Shop.

    this.stream.writeVInt(0) // AdsArray

    this.stream.writeVInt(200) // BattleTokens
    this.stream.writeVInt(0)

    this.stream.writeVInt(0)

    this.stream.writeVInt(9339) // Tickets
    this.stream.writeVInt(0)

    this.stream.writeDataReference(16, 0)//brawlerID

    this.stream.writeString('RU')
    this.stream.writeString("MixServers")//authorCode

    this.stream.writeVInt(3) // IntValueArray
    this.stream.writeInt(3) 
    this.stream.writeInt(0) //tokensAnim
    this.stream.writeInt(4) 
    this.stream.writeInt(0) //trophiesAnim
    this.stream.writeInt(5) 
    this.stream.writeInt(0) //bigTokensAnim

    this.stream.writeVInt(2019049)

    this.stream.writeVInt(100)

    this.stream.writeVInt(10)

    this.stream.writeLogicLong(30, 3)

    this.stream.writeLogicLong(80, 10)

    this.stream.writeLogicLong(50, 1000)

    this.stream.writeVInt(500)
    this.stream.writeVInt(50)
    this.stream.writeVInt(999900)

    this.stream.writeVInt(0) // Array

    this.maps = [
      {
        slotID: 1,
        mapID: 7,
        modifier: 0,
        length: 86400
    }
    ]
    this.stream.writeVInt(this.maps.length)
    for (const map of this.maps) {
      this.stream.writeVInt(map.slotID)
    }

    this.stream.writeVInt(this.maps.length)
    for (const map of this.maps) {
      this.stream.writeVInt(this.maps.indexOf(map) + 1)
      this.stream.writeVInt(map.slotID)
      this.stream.writeVInt(0)
      this.stream.writeVInt(map.length) // length

      this.stream.writeVInt(10) // tokens
      this.stream.writeDataReference(15, map.mapID)

      this.stream.writeVInt(1) // status

      this.stream.writeString()
      this.stream.writeVInt(0)

      this.stream.writeBoolean(map.modifier != 0)
      if (map.modifier != 0) {
        this.stream.writeVInt(map.modifier)
      }

      this.stream.writeVInt(0)
    }

    this.stream.writeVInt(0) // Coming events array

    this.stream.writeVInt(8)
    for (const i of [20, 35, 75, 140, 290, 480, 800, 1250]) {
      this.stream.writeVInt(i)
    }

    this.stream.writeVInt(8)
    for (const i of [1, 2, 3, 4, 5, 10, 15, 20]) {
      this.stream.writeVInt(i)
    }

    this.stream.writeVInt(3)
    for (const i of [10, 30, 80]) {
      this.stream.writeVInt(i)
    }

    this.stream.writeVInt(3)
    for (const i of [6, 20, 60]) {
      this.stream.writeVInt(i)
    }

    this.stream.writeVInt(3)
    for (const i of [20, 50, 140]) {
      this.stream.writeVInt(i)
    }

    this.stream.writeVInt(3)
    for (const i of [150, 400, 1200]) {
      this.stream.writeVInt(i)
    }

    this.stream.writeVInt(0)
    this.stream.writeVInt(200) // Max tokens
    this.stream.writeVInt(20)

    this.stream.writeVInt(8640)
    this.stream.writeVInt(10)
    this.stream.writeVInt(5)

    this.stream.writeVInt(6)

    this.stream.writeVInt(50)
    this.stream.writeVInt(604800)
    
    this.stream.writeBoolean(true)

    this.stream.writeVInt(0)

    this.stream.writeVInt(1)
    this.stream.writeLong(1, 41000000)

    this.stream.writeLong(0, this.session.Player.lowID)

    this.stream.writeVInt(0) // NotificationFactory
    // this.stream.writeVInt(81) // NotificationID
    // this.stream.writeInt(0) // NotificattitonIndex
    // this.stream.writeBoolean(true) // isSeen
    // this.stream.writeInt(0) // Time ago was received
    // this.stream.writeString('Spooky.js started!') // Message
    // this.stream.writeVInt(1) // sentBy (0 - Tech. Support, 1 - System)

    this.stream.writeBoolean(false)

    this.stream.writeLogicLong(0, 0)
    this.stream.writeLogicLong(0, this.session.Player.lowID)
    this.stream.writeLogicLong(0, 0)
    this.stream.writeLogicLong(0, 0)

    this.stream.writeString(this.session.Player.name)
    this.stream.writeVInt(this.session.Player.name !== "JSV19" ? 1 : 0);


    this.stream.writeString()

    this.stream.writeVInt(8)

    this.stream.writeVInt(this.brawlers.length + 4)

    for (const brawler of this.brawlers) {
      this.stream.writeDataReference(23, brawler.cardID)
      this.stream.writeVInt(brawler.unlocked ? 1 : 0)
    }

    this.stream.writeDataReference(5, 1)
    this.stream.writeVInt(100) // Small Box tokens

    this.stream.writeDataReference(5, 8)
    this.stream.writeVInt(1000) // Coins

    this.stream.writeDataReference(5, 9)
    this.stream.writeVInt(10) // Big Box tokens

    this.stream.writeDataReference(5, 10)
    this.stream.writeVInt(100) // StarPoints
    this.stream.writeVInt(this.brawlers.length)
    for (const brawler of this.brawlers) {
      this.stream.writeDataReference(16, brawler.id)
      this.stream.writeVInt(brawler.trophies)
    }

    this.stream.writeVInt(this.brawlers.length)
    for (const brawler of this.brawlers) {
      this.stream.writeDataReference(16, brawler.id)
      this.stream.writeVInt(brawler.highTrophies)
    }

    this.stream.writeVInt(0) // UnknownArray

    this.stream.writeVInt(this.brawlers.length)
    for (const brawler of this.brawlers) {
      this.stream.writeDataReference(16, brawler.id)
      this.stream.writeVInt(brawler.points)
    }

    this.stream.writeVInt(this.brawlers.length)
    for (const brawler of this.brawlers) {
      this.stream.writeDataReference(16, brawler.id)
      this.stream.writeVInt(brawler.level)
    }

    this.stream.writeVInt(0)//skills.length)
    // for(let skill of skills){
    //   this.stream.writeDataReference(23, skill)
    //   this.stream.writeVInt(this.player.brawlers[this.player.homeBrawler].skill == skill ? 2 : 1)
    // }

    this.stream.writeVInt(0)//this.player.brawlers.length)
    // for (const brawler of this.player.brawlers) {
    //   this.stream.writeDataReference(16, brawler.id)
    //   this.stream.writeVInt(brawler.new ? 1 : 0)
    // }

    this.stream.writeVInt(100)//this.player.gems)
    this.stream.writeVInt(100)//this.player.gems)
    this.stream.writeVInt(1)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(0)
    this.stream.writeVInt(2)
    this.stream.writeVInt(1585502369)
  }
}

module.exports = OwnHomeDataMessage
