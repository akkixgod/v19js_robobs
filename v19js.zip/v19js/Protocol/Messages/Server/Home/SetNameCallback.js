const PiranhaMessage = require('../../../PiranhaMessage') // You should change it if you transfer this file in another subdirectory
const ByteStream = require("../../../../ByteStream")

class SetNameCallback extends PiranhaMessage {
  constructor(session) {
    super(session);
    this.id = 24111;
    this.session = session;
    this.version = 1;
    this.stream = new ByteStream();
  }

  async encode() {
    this.stream.writeVInt(201);
    this.stream.writeString(this.session.Player.name);
    this.stream.writeVInt(0);
  }
}

module.exports = SetNameCallback;
